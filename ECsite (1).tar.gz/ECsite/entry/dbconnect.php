<?php 

$db=mysqli_connect('localhost','codecamp38173','codecamp38173','codecamp38173')or
 die(mysqli_connect_error());
mysqli_set_charset($db,'utf8');

?>
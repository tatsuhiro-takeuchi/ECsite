
<p>ユーザー登録が完了しました。</p>
<a href="../login/login.php">ログインする。</a>